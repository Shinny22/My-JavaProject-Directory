package cfi.ciras.devoir;

public interface société {

	public double Droit();
	public String Destination();
}
