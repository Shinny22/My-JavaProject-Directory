package cfi.ciras.devoir;

public class TestDevoir {

	public static void main(String args[]) {
		
		
		Produit produit=new Produit();
	}
}
