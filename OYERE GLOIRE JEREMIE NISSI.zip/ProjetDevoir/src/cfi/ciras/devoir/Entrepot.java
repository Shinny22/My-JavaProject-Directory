package cfi.ciras.devoir;
import java.util.ArrayList;

public class Entrepot extends Produit {

	
	Entrepot(int identifiant, String désignation, double prixHorsTaxe) {
		super(identifiant, désignation, prixHorsTaxe);
		// TODO Auto-generated constructor stub
	}

	ArrayList <Produit> produit =new ArrayList<>();
		
		public void ajouter() {
			
			produit.add("Montre");
			produit.add("Vetement");
			produit.add("Balain");
			produit.add("Brosse");
			
		}
		public boolean rechercher() {
			for(Produit element:produit) {
				
				
			}
			
		}
		
		@Override
		public String toString() {
			
			return désignation;
			
		}	
		
}
